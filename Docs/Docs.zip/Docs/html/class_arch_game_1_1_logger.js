var class_arch_game_1_1_logger =
[
    [ "Logger", "class_arch_game_1_1_logger.html#ae73b7cf725848283bcbca901b5188e9f", null ],
    [ "Dispose", "class_arch_game_1_1_logger.html#aca1ac119efb05a6d1e124baf3ba94049", null ],
    [ "Log", "class_arch_game_1_1_logger.html#a5dcd93e0adfe150d6354df4ec2533020", null ],
    [ "Log", "class_arch_game_1_1_logger.html#acd78294a2938abe79db16938bee297a1", null ],
    [ "Log", "class_arch_game_1_1_logger.html#ab5efa5a9dfd458f0e700c4cdf1a85223", null ],
    [ "Log", "class_arch_game_1_1_logger.html#a7b06c7f25e008bdc6a1e780451998fcd", null ],
    [ "writer", "class_arch_game_1_1_logger.html#ae00ab0c8ca0be94f9e026d17dbe42b4b", null ]
];