var _input_manager_8cs =
[
    [ "InputManager", "class_arch_game_1_1_input_1_1_input_manager.html", "class_arch_game_1_1_input_1_1_input_manager" ],
    [ "MouseAction", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afd", [
      [ "Left", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afda945d5e233cf7d6240f6b783b36a374ff", null ],
      [ "Right", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afda92b09c7c48c520c3c55e497875da437c", null ],
      [ "Middle", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afdab1ca34f82e83c52b010f86955f264e05", null ],
      [ "ScrollWheelUp", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afda22b05439ce87db0bd483c6b0a74cb8bc", null ],
      [ "ScrollWheelDown", "_input_manager_8cs.html#a7600f660d23388959d7872a134071afdac74e859fe1141c5cb34b2847952f6bdc", null ]
    ] ]
];