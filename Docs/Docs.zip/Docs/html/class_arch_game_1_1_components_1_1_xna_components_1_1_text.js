var class_arch_game_1_1_components_1_1_xna_components_1_1_text =
[
    [ "Text", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ae2b436e4752f8d05513935482c1b27d9", null ],
    [ "Text", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ad36adb592bf88eb216842261511486b9", null ],
    [ "Text", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a6f23f057af922199245cb63cb5cdee9f", null ],
    [ "Text", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ada44bdfce96877d1913752bbf532a411", null ],
    [ "Draw", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a3fbd2d3a35d69edde16be2459c359ec9", null ],
    [ "LoadContent", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ab6e8ee2e995a9017ce6e2370dca14a30", null ],
    [ "Color", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#af46f3e2cef38630d302dff137ccd942d", null ],
    [ "Effects", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ab633085e50bd9e70dd2e5aca7ff890f0", null ],
    [ "LayerDepth", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a29af6010240c5f30c9c15cf311ee2bd3", null ],
    [ "Origin", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#aed04817405aaad1b6857b4d3a55b19a2", null ],
    [ "Position", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a8db0b326164fc108ea84365b34abc788", null ],
    [ "Rotation", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ab76a493820fb5fc9683852ee24d67896", null ],
    [ "Scale", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a1f697172a92b72c6c70947126ec8459b", null ],
    [ "Center", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a192d2ed2d113aec21873e23b7410aaa7", null ],
    [ "TextToDraw", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a8b0719e14dbbb5527f7e884f6afa838b", null ],
    [ "ZIndex", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a8180c1a1bcae4b33fedab6e437fb4817", null ]
];