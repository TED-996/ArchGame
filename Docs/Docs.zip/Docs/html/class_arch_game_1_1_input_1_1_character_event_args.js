var class_arch_game_1_1_input_1_1_character_event_args =
[
    [ "CharacterEventArgs", "class_arch_game_1_1_input_1_1_character_event_args.html#ae4634ca5f49905883c5510934c7978ff", null ],
    [ "Character", "class_arch_game_1_1_input_1_1_character_event_args.html#adc5e98ce5f486b31835541f5045b02e8", null ]
];