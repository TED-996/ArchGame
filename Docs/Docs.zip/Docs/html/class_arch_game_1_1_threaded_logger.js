var class_arch_game_1_1_threaded_logger =
[
    [ "ThreadedLogger", "class_arch_game_1_1_threaded_logger.html#ab7cddb11f9a23594bbcc1697be075288", null ],
    [ "Dispose", "class_arch_game_1_1_threaded_logger.html#a5c3d4f325ea04565c9844d1bb3693a51", null ],
    [ "Log", "class_arch_game_1_1_threaded_logger.html#a569c6b5de271ed7d0ab9f90dc21bd443", null ]
];