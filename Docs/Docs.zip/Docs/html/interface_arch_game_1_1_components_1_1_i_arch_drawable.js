var interface_arch_game_1_1_components_1_1_i_arch_drawable =
[
    [ "Draw", "interface_arch_game_1_1_components_1_1_i_arch_drawable.html#ac701c4ed68b5cab0ab5215ca7877ef4f", null ]
];