var namespace_arch_game_1_1_components_1_1_xna_components =
[
    [ "Sprite", "class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html", "class_arch_game_1_1_components_1_1_xna_components_1_1_sprite" ],
    [ "Text", "class_arch_game_1_1_components_1_1_xna_components_1_1_text.html", "class_arch_game_1_1_components_1_1_xna_components_1_1_text" ]
];