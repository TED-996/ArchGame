var class_arch_game_1_1_misc_1_1_win32_utils =
[
    [ "WindowStyle", "class_arch_game_1_1_misc_1_1_win32_utils.html#a9609a857d3daa3b539480e7752d5bc46", [
      [ "Normal", "class_arch_game_1_1_misc_1_1_win32_utils.html#a9609a857d3daa3b539480e7752d5bc46a960b44c579bc2f6818d2daaf9e4c16f0", null ],
      [ "Minimized", "class_arch_game_1_1_misc_1_1_win32_utils.html#a9609a857d3daa3b539480e7752d5bc46a074afcc50ae51f248cbae4950845549e", null ],
      [ "Maximized", "class_arch_game_1_1_misc_1_1_win32_utils.html#a9609a857d3daa3b539480e7752d5bc46a49d903a5c02560cf79bf6b516cc89457", null ]
    ] ],
    [ "ChangeWindowSize", "class_arch_game_1_1_misc_1_1_win32_utils.html#ae2fa5a96120da2cebbe5188a346c269e", null ]
];