var _logger_8cs =
[
    [ "ILogger", "interface_arch_game_1_1_i_logger.html", "interface_arch_game_1_1_i_logger" ],
    [ "Logger", "class_arch_game_1_1_logger.html", "class_arch_game_1_1_logger" ],
    [ "ThreadedLogger", "class_arch_game_1_1_threaded_logger.html", "class_arch_game_1_1_threaded_logger" ],
    [ "ConsoleLogger", "class_arch_game_1_1_console_logger.html", "class_arch_game_1_1_console_logger" ],
    [ "NullLogger", "class_arch_game_1_1_null_logger.html", "class_arch_game_1_1_null_logger" ],
    [ "LogMessage", "struct_arch_game_1_1_log_message.html", "struct_arch_game_1_1_log_message" ],
    [ "LogMessageType", "_logger_8cs.html#aa6507993887ac9409911f0171e3d12f4", [
      [ "Information", "_logger_8cs.html#aa6507993887ac9409911f0171e3d12f4aa82be0f551b8708bc08eb33cd9ded0cf", null ],
      [ "Warning", "_logger_8cs.html#aa6507993887ac9409911f0171e3d12f4a0eaadb4fcb48a0a0ed7bc9868be9fbaa", null ],
      [ "Error", "_logger_8cs.html#aa6507993887ac9409911f0171e3d12f4a902b0d55fddef6f8d651fe1035b7d4bd", null ]
    ] ]
];