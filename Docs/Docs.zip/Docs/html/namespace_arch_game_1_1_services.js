var namespace_arch_game_1_1_services =
[
    [ "IServiceProvider", "interface_arch_game_1_1_services_1_1_i_service_provider.html", "interface_arch_game_1_1_services_1_1_i_service_provider" ],
    [ "LoggerProvider", "class_arch_game_1_1_services_1_1_logger_provider.html", "class_arch_game_1_1_services_1_1_logger_provider" ],
    [ "ServiceLocator", "class_arch_game_1_1_services_1_1_service_locator.html", "class_arch_game_1_1_services_1_1_service_locator" ],
    [ "ServiceProvider< T >", "class_arch_game_1_1_services_1_1_service_provider_3_01_t_01_4.html", "class_arch_game_1_1_services_1_1_service_provider_3_01_t_01_4" ]
];