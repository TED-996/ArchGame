var class_arch_game_1_1_services_1_1_logger_provider =
[
    [ "GetMockService", "class_arch_game_1_1_services_1_1_logger_provider.html#a467df4daf04f4e37de1349454407b574", null ]
];