var interface_arch_game_1_1_i_logger =
[
    [ "Log", "interface_arch_game_1_1_i_logger.html#aa99775e250f80b02cf65556e34ab0220", null ],
    [ "Log", "interface_arch_game_1_1_i_logger.html#ac6044e84220767c0c44ed7cf241e7a72", null ],
    [ "Log", "interface_arch_game_1_1_i_logger.html#a8ae775350ae1a9b604f87e932b66b715", null ],
    [ "Log", "interface_arch_game_1_1_i_logger.html#a0225555ad16d533b774ae8d3207b41c2", null ]
];