var struct_arch_game_1_1_log_message =
[
    [ "LogMessage", "struct_arch_game_1_1_log_message.html#a51ff22df5c5b8a8462c98a899358d142", null ],
    [ "LogMessage", "struct_arch_game_1_1_log_message.html#adf0eddd03115ef2143d1b3f3338040e1", null ],
    [ "LogMessage", "struct_arch_game_1_1_log_message.html#a4741cc04eb910d8b4138de191f7ed9ec", null ],
    [ "ToString", "struct_arch_game_1_1_log_message.html#a04b0eddb49509b4f9186e595a47eab1e", null ],
    [ "DateTime", "struct_arch_game_1_1_log_message.html#a81694cf0b25ec323f71902bea45c2034", null ],
    [ "Message", "struct_arch_game_1_1_log_message.html#a08f3dbcb5ba8cf731a93082b6485c685", null ],
    [ "MessageType", "struct_arch_game_1_1_log_message.html#a4f62cb4186739a6210558f0b3657da3e", null ],
    [ "Sender", "struct_arch_game_1_1_log_message.html#a6d5ba46f019358605a676a0d3a43f3a4", null ]
];