var NAVTREEINDEX2 =
{
"struct_arch_game_1_1_log_message.html#a81694cf0b25ec323f71902bea45c2034":[1,0,0,12,4],
"struct_arch_game_1_1_log_message.html#adf0eddd03115ef2143d1b3f3338040e1":[1,0,0,12,1]
};
