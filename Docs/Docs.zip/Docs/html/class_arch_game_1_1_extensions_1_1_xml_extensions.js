var class_arch_game_1_1_extensions_1_1_xml_extensions =
[
    [ "XmlDeserialize< T >", "class_arch_game_1_1_extensions_1_1_xml_extensions.html#a19cce86f2c196dfc576d3a6319299a56", null ],
    [ "XmlSerialize< T >", "class_arch_game_1_1_extensions_1_1_xml_extensions.html#ad45802e3c1f6c39f313efb8aae9dfc52", null ]
];