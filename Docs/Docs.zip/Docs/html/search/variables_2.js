var searchData=
[
  ['effects',['Effects',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#a8cac71c632538137b1526b1c20686fc0',1,'ArchGame.Components.XnaComponents.Sprite.Effects()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ab633085e50bd9e70dd2e5aca7ff890f0',1,'ArchGame.Components.XnaComponents.Text.Effects()']]]
];
