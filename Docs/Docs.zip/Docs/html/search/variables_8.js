var searchData=
[
  ['position',['Position',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#ae3c7e106f14b0f2d35a7b33b3070fc23',1,'ArchGame.Components.XnaComponents.Sprite.Position()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#a8db0b326164fc108ea84365b34abc788',1,'ArchGame.Components.XnaComponents.Text.Position()']]]
];
