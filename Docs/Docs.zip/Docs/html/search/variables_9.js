var searchData=
[
  ['rotation',['Rotation',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#a48f2386befd690d8bc86321c54ee3975',1,'ArchGame.Components.XnaComponents.Sprite.Rotation()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#ab76a493820fb5fc9683852ee24d67896',1,'ArchGame.Components.XnaComponents.Text.Rotation()']]]
];
