var searchData=
[
  ['color',['Color',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#a7a8d9cae99c503c4e118a33ecac8ae9b',1,'ArchGame.Components.XnaComponents.Sprite.Color()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#af46f3e2cef38630d302dff137ccd942d',1,'ArchGame.Components.XnaComponents.Text.Color()']]],
  ['componentlist',['componentList',['../class_arch_game_1_1_states_1_1_state.html#af95cc63e6723e80f1464d90f0bc5e5b3',1,'ArchGame::States::State']]]
];
