var searchData=
[
  ['text_2ecs',['Text.cs',['../_text_8cs.html',1,'']]]
];
