var searchData=
[
  ['xmldeserialize_3c_20t_20_3e',['XmlDeserialize&lt; T &gt;',['../class_arch_game_1_1_extensions_1_1_xml_extensions.html#a19cce86f2c196dfc576d3a6319299a56',1,'ArchGame::Extensions::XmlExtensions']]],
  ['xmlextensions',['XmlExtensions',['../class_arch_game_1_1_extensions_1_1_xml_extensions.html',1,'ArchGame::Extensions']]],
  ['xmlextensions_2ecs',['XmlExtensions.cs',['../_xml_extensions_8cs.html',1,'']]],
  ['xmlserialize_3c_20t_20_3e',['XmlSerialize&lt; T &gt;',['../class_arch_game_1_1_extensions_1_1_xml_extensions.html#ad45802e3c1f6c39f313efb8aae9dfc52',1,'ArchGame::Extensions::XmlExtensions']]],
  ['xnaextensions',['XnaExtensions',['../class_arch_game_1_1_extensions_1_1_xna_extensions.html',1,'ArchGame::Extensions']]],
  ['xnaextensions_2ecs',['XnaExtensions.cs',['../_xna_extensions_8cs.html',1,'']]]
];
