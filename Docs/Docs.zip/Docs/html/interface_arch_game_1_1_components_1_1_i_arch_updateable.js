var interface_arch_game_1_1_components_1_1_i_arch_updateable =
[
    [ "Update", "interface_arch_game_1_1_components_1_1_i_arch_updateable.html#a5413ffc39a97ff08682a6dbe124fd513", null ],
    [ "UpdatePriority", "interface_arch_game_1_1_components_1_1_i_arch_updateable.html#a6f16401b1a559342acb88191f6c61428", null ]
];