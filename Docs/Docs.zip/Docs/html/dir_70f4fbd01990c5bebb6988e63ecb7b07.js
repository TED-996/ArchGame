var dir_70f4fbd01990c5bebb6988e63ecb7b07 =
[
    [ "ClipboardManager.cs", "_clipboard_manager_8cs.html", [
      [ "ClipboardManager", "class_arch_game_1_1_input_1_1_clipboard_manager.html", "class_arch_game_1_1_input_1_1_clipboard_manager" ]
    ] ],
    [ "EventInputManager.cs", "_event_input_manager_8cs.html", "_event_input_manager_8cs" ],
    [ "InputManager.cs", "_input_manager_8cs.html", "_input_manager_8cs" ],
    [ "StringInputProcessor.cs", "_string_input_processor_8cs.html", [
      [ "StringInputProcessor", "class_arch_game_1_1_input_1_1_string_input_processor.html", "class_arch_game_1_1_input_1_1_string_input_processor" ]
    ] ]
];