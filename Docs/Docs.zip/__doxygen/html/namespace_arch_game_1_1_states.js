var namespace_arch_game_1_1_states =
[
    [ "State", "class_arch_game_1_1_states_1_1_state.html", "class_arch_game_1_1_states_1_1_state" ],
    [ "StateManager", "class_arch_game_1_1_states_1_1_state_manager.html", "class_arch_game_1_1_states_1_1_state_manager" ]
];