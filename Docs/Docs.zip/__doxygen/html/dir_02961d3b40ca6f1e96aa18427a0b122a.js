var dir_02961d3b40ca6f1e96aa18427a0b122a =
[
    [ "Logger.cs", "_logger_8cs.html", "_logger_8cs" ],
    [ "Win32Utils.cs", "_win32_utils_8cs.html", [
      [ "Win32Utils", "class_arch_game_1_1_misc_1_1_win32_utils.html", "class_arch_game_1_1_misc_1_1_win32_utils" ]
    ] ]
];