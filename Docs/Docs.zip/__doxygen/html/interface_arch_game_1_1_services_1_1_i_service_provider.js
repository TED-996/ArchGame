var interface_arch_game_1_1_services_1_1_i_service_provider =
[
    [ "GetService", "interface_arch_game_1_1_services_1_1_i_service_provider.html#abb1fbd432165ce337b7627624c8a6ff1", null ],
    [ "GetServiceType", "interface_arch_game_1_1_services_1_1_i_service_provider.html#a160b66520ca13c781bc856cdcda8f9ec", null ],
    [ "SetService", "interface_arch_game_1_1_services_1_1_i_service_provider.html#a2511038be3a5bcdfb6d11c2e86c90b46", null ]
];