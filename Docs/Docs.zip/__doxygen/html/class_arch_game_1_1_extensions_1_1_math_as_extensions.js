var class_arch_game_1_1_extensions_1_1_math_as_extensions =
[
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a820d17962fd647f01e45d7da30a090f1", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a6ad1c3fb42bd845fdaef1b6ccb30f86c", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a0098613232b0b4f2c27e559f4d66f31f", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a73caa6a58723c89c14fc23ae3c6cf1ad", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a8cabb063188ad2d87420bef1942d6f0b", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a829b05efd1f199f8f7a6e838b046c97d", null ],
    [ "Abs", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#abbb7e8f39de7b45489bd4a40e4a12bf3", null ],
    [ "AtLeast< T >", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a2a728debd31ec9705d42c446702971e0", null ],
    [ "AtMost< T >", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a2f0802c88cf81e2cafd81ec8e395230c", null ],
    [ "Clamp< T >", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a9dad6eb7e9c266cb39b0bdf804fb304f", null ],
    [ "RoundToInt", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a51c0c49659c02eaf2c61973033397a9f", null ],
    [ "RoundToInt", "class_arch_game_1_1_extensions_1_1_math_as_extensions.html#a83ddcedede0064f74de210025be483b1", null ]
];