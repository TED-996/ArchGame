var searchData=
[
  ['nulllogger',['NullLogger',['../class_arch_game_1_1_misc_1_1_null_logger.html',1,'ArchGame::Misc']]]
];
