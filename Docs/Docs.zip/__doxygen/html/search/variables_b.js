var searchData=
[
  ['writer',['writer',['../class_arch_game_1_1_misc_1_1_logger.html#a7d1cea07d78e07677459fb44a7a4cc9b',1,'ArchGame::Misc::Logger']]]
];
