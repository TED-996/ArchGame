var searchData=
[
  ['writer',['writer',['../class_arch_game_1_1_logger.html#ae00ab0c8ca0be94f9e026d17dbe42b4b',1,'ArchGame::Logger']]]
];
