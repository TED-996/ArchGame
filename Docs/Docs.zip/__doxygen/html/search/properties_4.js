var searchData=
[
  ['mousex',['MouseX',['../class_arch_game_1_1_input_1_1_input_manager.html#a95aa1392b6779b67737ee08371bd8906',1,'ArchGame::Input::InputManager']]],
  ['mousey',['MouseY',['../class_arch_game_1_1_input_1_1_input_manager.html#af61240d920ee4f7e51d5cbe9d2088dbd',1,'ArchGame::Input::InputManager']]]
];
