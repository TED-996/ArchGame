var searchData=
[
  ['color',['Color',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#a7a8d9cae99c503c4e118a33ecac8ae9b',1,'ArchGame.Components.XnaComponents.Sprite.Color()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#af46f3e2cef38630d302dff137ccd942d',1,'ArchGame.Components.XnaComponents.Text.Color()']]],
  ['componentlist',['componentList',['../class_arch_game_1_1_components_1_1_component_list_user.html#af3e0c4d059d8dd5abd930aec6c2dcbc2',1,'ArchGame::Components::ComponentListUser']]]
];
