var class_arch_game_1_1_modules_1_1_type_string_pair =
[
    [ "TypeStringPair", "class_arch_game_1_1_modules_1_1_type_string_pair.html#abc645e5305d779a327052d54b42881cd", null ],
    [ "String", "class_arch_game_1_1_modules_1_1_type_string_pair.html#a8c4bc761c254254c1cd57052a6327e49", null ],
    [ "Type", "class_arch_game_1_1_modules_1_1_type_string_pair.html#a8bce20e24de0fd357ab8084f25a2e934", null ]
];