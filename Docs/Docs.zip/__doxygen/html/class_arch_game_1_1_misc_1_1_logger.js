var class_arch_game_1_1_misc_1_1_logger =
[
    [ "Logger", "class_arch_game_1_1_misc_1_1_logger.html#a26f6741f4694261e856664771c6652fd", null ],
    [ "Dispose", "class_arch_game_1_1_misc_1_1_logger.html#a56b54e75466468fe69e04ecf1c621acf", null ],
    [ "Log", "class_arch_game_1_1_misc_1_1_logger.html#a6fe363230fd88fe374d98636c4ddc757", null ],
    [ "Log", "class_arch_game_1_1_misc_1_1_logger.html#a323ced439da7569e003b4f77e21347a7", null ],
    [ "Log", "class_arch_game_1_1_misc_1_1_logger.html#ac43773abbb3aa96ee27058bf4e929383", null ],
    [ "Log", "class_arch_game_1_1_misc_1_1_logger.html#aa00d824481a47ea960c7172c470a493b", null ],
    [ "writer", "class_arch_game_1_1_misc_1_1_logger.html#a7d1cea07d78e07677459fb44a7a4cc9b", null ]
];