var dir_5edf23ed69dc7b77fbbf2cc59521cca6 =
[
    [ "ClipboardManager.cs", "_clipboard_manager_8cs.html", [
      [ "ClipboardManager", "class_arch_game_1_1_input_1_1_clipboard_manager.html", "class_arch_game_1_1_input_1_1_clipboard_manager" ]
    ] ],
    [ "EventInputManager.cs", "_event_input_manager_8cs.html", "_event_input_manager_8cs" ],
    [ "InputManager.cs", "_input_manager_8cs.html", "_input_manager_8cs" ],
    [ "IObstructionManager.cs", "_i_obstruction_manager_8cs.html", [
      [ "IObstructionManager", "interface_arch_game_1_1_input_1_1_i_obstruction_manager.html", "interface_arch_game_1_1_input_1_1_i_obstruction_manager" ]
    ] ],
    [ "StringInputProcessor.cs", "_string_input_processor_8cs.html", [
      [ "StringInputProcessor", "class_arch_game_1_1_input_1_1_string_input_processor.html", "class_arch_game_1_1_input_1_1_string_input_processor" ]
    ] ]
];