var interface_arch_game_1_1_modules_1_1_i_module_requester =
[
    [ "GetRequestedModules", "interface_arch_game_1_1_modules_1_1_i_module_requester.html#aad395e6cabbb0a44ac1e02893749a131", null ],
    [ "SetModules", "interface_arch_game_1_1_modules_1_1_i_module_requester.html#a03deda6a4fdb59da7bbdccb94959bc67", null ]
];