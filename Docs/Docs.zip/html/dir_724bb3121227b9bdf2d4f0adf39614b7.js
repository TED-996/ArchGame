var dir_724bb3121227b9bdf2d4f0adf39614b7 =
[
    [ "IServiceProvider.cs", "_i_service_provider_8cs.html", [
      [ "IServiceProvider", "interface_arch_game_1_1_services_1_1_i_service_provider.html", "interface_arch_game_1_1_services_1_1_i_service_provider" ],
      [ "ServiceProvider< T >", "class_arch_game_1_1_services_1_1_service_provider_3_01_t_01_4.html", "class_arch_game_1_1_services_1_1_service_provider_3_01_t_01_4" ]
    ] ],
    [ "ServiceLocator.cs", "_service_locator_8cs.html", [
      [ "ServiceLocator", "class_arch_game_1_1_services_1_1_service_locator.html", "class_arch_game_1_1_services_1_1_service_locator" ]
    ] ],
    [ "ServiceProviders.cs", "_service_providers_8cs.html", [
      [ "LoggerProvider", "class_arch_game_1_1_services_1_1_logger_provider.html", "class_arch_game_1_1_services_1_1_logger_provider" ]
    ] ]
];