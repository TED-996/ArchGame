var dir_3d454fcf38b4d686c9c0a8e3d14b016d =
[
    [ "IModuleConstructor.cs", "_i_module_constructor_8cs.html", [
      [ "IModuleConstructor", "interface_arch_game_1_1_modules_1_1_i_module_constructor.html", "interface_arch_game_1_1_modules_1_1_i_module_constructor" ],
      [ "ModuleConstructor< TImpl, TInterface >", "class_arch_game_1_1_modules_1_1_module_constructor_3_01_t_impl_00_01_t_interface_01_4.html", "class_arch_game_1_1_modules_1_1_module_constructor_3_01_t_impl_00_01_t_interface_01_4" ],
      [ "LambdaConstructor< TImpl, TInterface >", "class_arch_game_1_1_modules_1_1_lambda_constructor_3_01_t_impl_00_01_t_interface_01_4.html", "class_arch_game_1_1_modules_1_1_lambda_constructor_3_01_t_impl_00_01_t_interface_01_4" ]
    ] ],
    [ "IModuleProvider.cs", "_i_module_provider_8cs.html", [
      [ "IModuleProvider", "interface_arch_game_1_1_modules_1_1_i_module_provider.html", "interface_arch_game_1_1_modules_1_1_i_module_provider" ],
      [ "ModuleProvider< T >", "class_arch_game_1_1_modules_1_1_module_provider_3_01_t_01_4.html", "class_arch_game_1_1_modules_1_1_module_provider_3_01_t_01_4" ]
    ] ],
    [ "IModuleRequester.cs", "_i_module_requester_8cs.html", [
      [ "IModuleRequester", "interface_arch_game_1_1_modules_1_1_i_module_requester.html", "interface_arch_game_1_1_modules_1_1_i_module_requester" ]
    ] ],
    [ "ModuleCollection.cs", "_module_collection_8cs.html", [
      [ "ModuleCollection", "class_arch_game_1_1_modules_1_1_module_collection.html", "class_arch_game_1_1_modules_1_1_module_collection" ],
      [ "TypeStringPair", "class_arch_game_1_1_modules_1_1_type_string_pair.html", "class_arch_game_1_1_modules_1_1_type_string_pair" ]
    ] ],
    [ "ModuleFactory.cs", "_module_factory_8cs.html", [
      [ "ModuleFactory", "class_arch_game_1_1_modules_1_1_module_factory.html", "class_arch_game_1_1_modules_1_1_module_factory" ]
    ] ],
    [ "ModuleProviders.cs", "_module_providers_8cs.html", [
      [ "GenericModuleProvider< T >", "class_arch_game_1_1_modules_1_1_generic_module_provider_3_01_t_01_4.html", "class_arch_game_1_1_modules_1_1_generic_module_provider_3_01_t_01_4" ]
    ] ]
];