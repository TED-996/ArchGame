var searchData=
[
  ['origin',['Origin',['../class_arch_game_1_1_components_1_1_xna_components_1_1_sprite.html#afa8cb07fc73fee84d01fe7dc699bba8a',1,'ArchGame.Components.XnaComponents.Sprite.Origin()'],['../class_arch_game_1_1_components_1_1_xna_components_1_1_text.html#aed04817405aaad1b6857b4d3a55b19a2',1,'ArchGame.Components.XnaComponents.Text.Origin()']]]
];
