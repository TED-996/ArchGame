var interface_arch_game_1_1_modules_1_1_i_module_provider =
[
    [ "GetModule", "interface_arch_game_1_1_modules_1_1_i_module_provider.html#aa317449b5bcbf26edc3c7a3766350e76", null ],
    [ "GetModuleType", "interface_arch_game_1_1_modules_1_1_i_module_provider.html#a14e7d84d9b8c4eaa82e72a932b61d7a5", null ],
    [ "SetModule", "interface_arch_game_1_1_modules_1_1_i_module_provider.html#a7fb17ac4ccc0e2901110a50f6fece7ab", null ]
];